<?php
declare(strict_types=1);

/*
 * Xitercsx Panel Website
 * Keep this file private. Never put API keys in frontend JavaScript.
 */
return [
    'site_name' => 'Xitercsx Panel',
    'panel_api_url' => getenv('YANNPANEL_URL') ?: 'https://zanspiwptero.shoppanel.my.id',
    'panel_api_key' => getenv('YANNPANEL_API_KEY') ?: 'ISI_API_KEY_RESELLER_DI_ENV',
    'panel_url' => getenv('YANNPANEL_PANEL_URL') ?: '',
    'timeout_seconds' => 25,
    'data_dir' => __DIR__ . '/data',
];
